package API;

public class P {
   private int x =10 ;
   private P() {
		  System.out.println("OMG!!! you accessed & Execued private Constuctor :-)");

   }
   private void m1() {
	  System.out.println("OMG!!! you Execued private method :-)");
   }
}
