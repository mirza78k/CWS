package API;

import java.util.Scanner;

public class Test01 {
     public static void main(String[] args)throws ClassNotFoundException , InstantiationException , IllegalAccessException {
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Rnter class name ");
		String cName = scn.next();
		
		Class cls = Class.forName(cName);
		Object obj =cls.newInstance();
		System.out.println(obj);
	}
}
