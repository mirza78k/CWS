package API;

import java.io.UncheckedIOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

public class Test02 {
    public static void main(String[] args)throws ClassNotFoundException , InstantiationException , IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        Scanner scn = new Scanner(System.in);
        
        System.out.println("Enter Class name");
    	String cName = scn.next();
    	Class cls =Class.forName(cName);
//    	Object obj1 =cls.newInstance();
//    	System.out.println("OBJ"+obj1);
//    	Constructor cons = cls.getConstructor();
   	Constructor<?>cons1 =cls.getConstructor();
    	Object obj2 =cons1.newInstance();
    	System.out.println("Obj2"+obj2);
    	@SuppressWarnings("Unchecked")
    	Constructor<?>cons2 = cls.getConstructor(int.class);
    	Object obj3 =cons1.newInstance(50);
    	System.out.println("obj 3 : "+obj3);
 
    	
    }	
}
