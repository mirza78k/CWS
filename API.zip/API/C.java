package API;

public class C {
	static int a  = m1();
		static int m1() {
			System.out.println("C sv : a");
			return 10 ;
		}
		int x = m2();
		int m2() {
			System.out.println("C NSV : "+x);
			return 20 ;
		}
		static {
			System.out.println("C SB ");
		}
		{
			System.out.println("C NSB");
		}
		 C() {
			System.out.println("C NPC");
		}
		C(int x){
			System.out.println("C IPC ");
			this.x=x;
		}	
		public static void main(String[] args) {
			System.out.println("C main");
		}
		static void m3() {
			System.out.println("C SM m3(NP)");
		}
		static int m3 (String s) {
			System.out.println("C SM m3(int) "+ s );
			return 10 ;
		}
		void m4() {
			System.out.println("C NSM m4(np) ");
		}
		String m4(double d) {
			System.out.println("C NSM m4(Float) "+ d);
			return "a" ;
		}
		
		
		
		
		
		
		
	

}
