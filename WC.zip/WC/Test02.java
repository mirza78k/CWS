package WC;

public class Test02 {
    public static void main(String[] args) {
		Integer io1 = Integer.valueOf(50);
		int       i = io1.intValue();
		byte      b = io1.byteValue();
		short     s = io1.shortValue();
		long      l = io1.byteValue();
		float     f = io1.byteValue();
		double    d = io1.byteValue();
		
		System.out.println(i);
		System.out.println(b);
		System.out.println(s);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
		System.out.println();
	}
}
