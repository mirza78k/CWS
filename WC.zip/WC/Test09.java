package WC;

import java.util.ArrayList;

public class Test09 {
    public static void main(String[] args) {
	    //boxing -> storing pv in wco
    	Integer io1 = new Integer(50);
    	
    	//Unboxing -> retrieving pv from WCO
    	int i1 = io1.intValue();
    	// in java 5v  AutoBoxing
    	
    	//.java              .class 
    	Integer io2 = 50 ;  //=> Integer io2 = Integer.valueOf(50);
    	
    	//in java 5v Unboxing 
    	
    	//.java                    // .class 
    	int i2 =io2 ;               // =>int i2 = io2.intValue();    
    	int i3 =new Integer(70);    //=> int i3 = new Integer(70).intvalue();
    	
    	//without AB and AUB
    	ArrayList al = new ArrayList();
    	al.add(new Integer(50) );
    	al.add(new Integer(60) );
    	al.add(new Integer(70) );
    	al.add(new Integer(80) );
    	
    	
    	
    }
}
