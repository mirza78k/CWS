package WC;

public class Exception {
    public static void main(String[] args) {
		System.out.println("Main Start");
		
	//	System.out.println(10/0); here we Exception java.lang.ArithmeticException
//		System.out.println(new  int[-5]); here we get Exception java.lang.NegativeArraySizeException
//		System.out.println(agrs[0]);CE:agrs cannot be resolved to a variable
//		System.out.println(Integer.parseInt("a"));exception throw  java.lang.NumberFormatException:
	    System.out.println("Main end");	
	}
}
