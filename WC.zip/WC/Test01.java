package WC;

public class Test01 {
     public static void main(String[] args) {
			/*			 * 
			 * public Byte(byte b)
			 * public Short(short s)
			 * public Integer(int i)
			 * public Long(long l)
			 * public double(double d)
			 * public Character(char ch)
			 * public Boolean(boolean b)
			 * 
			 */ 
//    	 public static Byte valueOf(byte value) {} 
    	 	 int i1 =5 ;
    	 	 Integer io1 = new Integer(5);
      	 	 Integer io2 = Integer.valueOf(5);
      	 	 System.out.println(i1);
      	 	 System.out.println(io1);
      	 	 System.out.println(io2);
      	 	 
      	 	 Integer io3 = new Integer(15);
      	 	 Integer io4 = new Integer(15);
      	 	 
      	 	 System.out.println(io3==io4);
      	 	 System.out.println();
      	 	 
      	 	 Integer io5 = Integer.valueOf(25);
      	 	 Integer io6 = Integer.valueOf(25);
      	 	 
      	 	 System.out.println(io5==io6);
      	 	 System.out.println();
      	 	 
      	 	 Integer io7 = new Integer(15);
      	 	 Integer io8 = Integer.valueOf(25);
      	 	 
      	 	 System.out.println(io7==io8);
      	 	 System.out.println();
      	 	 
      	 	 Integer io9 = Integer.valueOf(250);
      	 	 Integer io10 = Integer.valueOf(250);
      	 	 
      	 	 System.out.println(io9==io10);
      	 	 
      	 	 
      	 	 
      	 	 
      	 	 
      	 	 
      	 	 
      	 	 
      	 	 
      	 	 
      	 	 
      	 	 

     }
     
}
