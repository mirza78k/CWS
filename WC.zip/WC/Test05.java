package WC;

public class Test05 {
    public static void main(String[] args) {
		Integer io1 = Integer.valueOf(50);
		String s1 = io1.toString();
		
		System.out.println(io1);//WCO
		System.out.println(s1);//SO
	}
}
