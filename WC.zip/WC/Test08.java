package WC;

public class Test08 {
       public static void main(String[] args) {
		Integer io1 = new Integer(50);
		Long lo1 =new Long(50);
		
//		Integer io2 =new Long(50);
//		Long lo2 = new Integer(50);
		
		
		long l1 = 50 ;
		
	//System.out.println(io1==lo1);
		System.out.println(io1.equals(lo1));//false
		System.out.println();
		
		Integer io3 =new Integer(70);
		Integer io4 =new Integer(70);
		System.out.println(io3==io4);//false
		System.out.println(io3.equals(io4));//true
		System.out.println();

		Integer io5 =new Integer(70);
		Integer io6 =new Integer(70);
		System.out.println(io5==io6);//false
		System.out.println(io5.equals(io6));//true
		
		
		
		
		
	}
}
