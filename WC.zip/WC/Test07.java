package WC;

public class Test07 {
      public static void main(String[] args) {
//		Byte b1 = new Byte(5);
//		Byte b2 = Byte.valueOf(5);
    	  
		Byte b1 = new Byte((byte)5);
		Byte b2 = Byte.valueOf((byte)5);
    	  
		Short s1 = new Short((short)5);
		Short s2 = Short.valueOf((short)5);
		
		Long l1 = new Long((long)5);
		Long l2 = Long.valueOf((long)5);
		
		Integer i1 = new Integer((int)5);
		Integer i2 = Integer.valueOf((int)5);
		
		Float f1 = new Float((float)5);
		Float f2 = Float.valueOf((float)5);
		
		Double d1 = new Double((double)5);
		Double d2 = Double.valueOf((double)5);
		
		Character c1 = new Character((char)5);
		Character c2 = Character.valueOf((char)5);
		
//     	Boolean bo1 = new Boolean((boolean)5);
//		Boolean bo2 =Boolean.valueOf((boolean)5);
		

    	  
	}
}
