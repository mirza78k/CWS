package WC;

public class Test06 {
   public static void main(String[] args) {
	   int i1 = 60 ;
	  // String s1 = Integer.toString();CE
	   
	    String s1 = Integer.toString(i1);
	   
	    System.out.println(i1);// int type
	    System.out.println(s1);//String type
   }
}
