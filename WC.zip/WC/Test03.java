package WC;

public class Test03 {
public static void main(String[] args) {
	Integer io1=new Integer("50");
	Integer io2= Integer.valueOf("50");
	
	System.out.println(io1);
	System.out.println(io2);
	
//	Character ch1 = new Character("a");CE:
//	Character ch2 = Character.valueOf("a");CE:	
	
	String s1 = "a";
	char ch1 = s1.charAt(0);
	System.out.println(ch1);
	
	Integer io3 = Integer.valueOf("70");
	Integer io4 = Integer.valueOf("70");
	System.out.println(io3==io4);
	
	Integer io5 = Integer.valueOf("700");
	Integer io6 = Integer.valueOf("700");
	System.out.println(io5==io6);
	
 	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
}
