package WC;

public class Test04 {
	public static void main(String[] args) {
		String s1 = "50";
		//java 1.0 to 1.3v
		Integer io1 =Integer.valueOf(s1);//pso --> WCO
		int i1 =io1.intValue(); //WCO-->PV
		System.out.println(i1);
		
		//java 1.4v
		int i2 =Integer.parseInt(s1);//pso -->pv
		System.out.println(i2);
		
//		int i3 =Integer.parseInt("a");NO CE ,but RE:java.lang.NumberFormatException
//		int i4 =Integer.parseInt("10.5");

		Boolean b1 =Boolean.parseBoolean("true");System.out.println(b1);
		Boolean b2 =Boolean.parseBoolean("false");System.out.println(b2);
		Boolean b3 =Boolean.parseBoolean("abc");System.out.println(b3);
		Boolean b4 =Boolean.parseBoolean("TRUE");System.out.println(b4);
		Boolean b5 =Boolean.parseBoolean("193");System.out.println(b5);
	}
}
